const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'saro',
    database: 'contacts'
});

connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});

// Route to serve the index.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});


app.post('/submit', (req, res) => {
    const { Name, PhoneNo, Typeofenquiry, Message } = req.body;
    const INSERT_QUERY = 'INSERT INTO enquiries (Name, PhoneNo, Typeofenquiry, Message) VALUES (?, ?, ?, ?)';
    connection.query(INSERT_QUERY, [Name, PhoneNo, Typeofenquiry, Message], (err, result) => {
        if (err) throw err;
        console.log('Data inserted into database');
        res.send('Form submitted successfully');
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
